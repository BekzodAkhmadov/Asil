<?php

namespace Http\Admin\Product\Tests\Brand;

use App\Testing\Feature\PostmanTestCase;

class _TestCase extends PostmanTestCase
{
    public int $userId = 1;

    public string $requestUrl = 'admin/product/brand';
}
